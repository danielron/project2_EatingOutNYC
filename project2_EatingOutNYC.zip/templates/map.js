// GROUP 2 PROJECT 2 MAP LOGIC

// Make the canvas to fit in the div

var canvas = d3.select("#map")
    .append("svg:svg")
    .attr("width", 300)
    .attr("height", 300);
// var context = canvas.node().getContext('2d');



// Load restaurant information as JSON

d3.json("SIDEWALK.json", function createMarkers(data) {
    // Make an empty array to hold the restaurant markers
    var restaurants = [];
    // Loop through the restaurants to pull the location and popup data
    for (var i = 0; i < data.length; i++) {
        // A cleaner variable to point to each restaurant's data
        var restaurant = data[i];
        // Create the marker and popup info for each restaurant
        var marker = L.marker([restaurant.LATITUDE, restaurant.LONGITUDE])
            .bindPopup("<b>" + data[i].DBA + "</b><br>Cuisine: " + data[i].CUISINE + "<br>Latest Grade: " + data[i].GRADE + "<br>Seating Type: " + data[i].SWC_TYPE);
            // Add the restaurant to the array
            restaurants.push(marker)
        }
    
    // Make a layer group from the restaurant array and send it to the createMap function
    createMap(L.layerGroup(restaurants))
});


function createMap(restaurants) {
    // JF MapBox token: pk.eyJ1IjoiZnJpbXB0ZXIiLCJhIjoiY2podjQ5cXVwMHZkMzN2cnZyYnRtYmFleSJ9.hSiLEjkBIMFB4DOkbVMbMQ
    var MapBox = "https://api.mapbox.com/styles/v1/mapbox/outdoors-v10/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiZGFuaWVscm9uIiwiYSI6ImNqaTMwNDVsYjA0dzAzd3Btd2ZnNjZyZGYifQ.-ndj1FchBVAVbndcNqZVCw";

    // Make tile layer for the background
    var map = L.tileLayer(MapBox, {
        attribution: "Map data &copy; <a href=\"https://data.cityofnewyork.us/Health/DOHMH-New-York-City-Restaurant-Inspection-Results/xx67-kt59/data\">NYC OpenData</a>, Imagery by Group 2 © <a href=\"http://mapbox.com\">Mapbox</a>",
        maxZoom: 20
    });

    // Make a baseMaps object 
    var baseMaps = {
        "NYC": map
    };

    // Make an overlayMaps layer for the restaurants layer
    var overlayMaps = {
        "Outdoor Seating": restaurants
    };

    // Make the map object
    var myMap = L.map("map", {
        center: [40.7300411532146, -73.9581679438021], //40.7128, -74.0060
        zoom: 12,
        layers: [map, restaurants]
    });

    // Make a control layer
    L.control.layers(baseMaps, overlayMaps, {
        collapsed: false
    }).addTo(myMap);

};
